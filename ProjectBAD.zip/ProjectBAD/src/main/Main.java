package main;

public class Main {

	/*
	 BA19 - Business Application Development
	 Kelompok 2
	 2440045501 - Aisha Freena
	 2440054916 - Safira Audre
	 2401860174 - Meilieani
	 2440104920 - Muhammad Farras Zhafran
	 */
	
	public Main() {
		LoginM regis = new LoginM();

	}

	public static void main(String[] args) {
		new Main();

	}

}
